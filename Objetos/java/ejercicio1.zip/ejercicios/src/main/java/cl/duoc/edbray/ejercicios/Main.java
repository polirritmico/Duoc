package cl.duoc.edbray.ejercicios;

import cl.duoc.edbray.ejercicios.str1.ExerciseStringsI;

public class Main {
    public static void main(String[] args) {
        ExerciseStringsI str1 = new ExerciseStringsI();
        str1.run();
    }
}
