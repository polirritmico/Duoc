package cl.duoc.edbray.ejercicios.str2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

class ExerciseStringsIITest {
    private ExerciseStringsII app;

    @BeforeEach
    void setup() {
        app = new ExerciseStringsII();
    }

    @Test
    void ShouldCleanSpaces() {
        String caseValue = "  Carlos123 ";
        String expected = "Carlos123";
        String output = app.cleanSpaces(caseValue);
        assertEquals(expected, output);
    }

    @Test
    void ShouldDetectStringStartWithUppercase() {
        String caseValueTrue = "Aaa";
        String caseValueFalse = "bBB";
        boolean outputUppercase = app.beginWithUppercase(caseValueTrue);
        boolean outputLowercase = app.beginWithUppercase(caseValueFalse);
        assertTrue(outputUppercase);
        assertFalse(outputLowercase);
    }

    @Test
    void ShouldConvertToLowercase() {
        String caseValue = "aBCd";
        String expected = "abcd";
        String output = app.converToLowercase(caseValue);
        assertEquals(expected, output);
    }

    @Test
    void ShouldDetectDigitsInTheString() {
        // ¿Contiene números? true
        String caseValue1 = "aa2b";
        String caseValue2 = "abcd";
        boolean output1 = app.checkHasNumbers(caseValue1);
        boolean output2 = app.checkHasNumbers(caseValue2);
        assertTrue(output1);
        assertFalse(output2);
    }

    @Test
    void ShouldDetectIfStringEndsWithDigit() {
        String caseValue1 = "aaa1";
        String caseValue2 = "aaaa";
        boolean output1 = app.checkEndWithDigit(caseValue1);
        boolean output2 = app.checkEndWithDigit(caseValue2);
        assertTrue(output1);
        assertFalse(output2);
    }

    @Test
    void ShouldConvertToUppercase() {
        String caseValue = "aa12";
        String expected = "AA12";
        String output = app.convertToUppercase(caseValue);
        assertEquals(expected, output);
    }

    @Test
    void ShouldCountCharacters() {
        String caseValue = "abcdefghij";
        String expected = "10";
        String output = app.countCharacters(caseValue);
        assertEquals(expected, output);
    }
}