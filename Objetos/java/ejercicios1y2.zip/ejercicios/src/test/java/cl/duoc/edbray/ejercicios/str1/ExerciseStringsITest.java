package cl.duoc.edbray.ejercicios.str1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExerciseStringsITest {

    @Test
    void processSecretMessage() {
        String caseValue = "   Hola_mundo secreto__   ";
        String[] expectedLines = {
            "Mensaje original:    Hola_mundo secreto__   ",
            "Mensaje procesado: Hola mundo secreto",
            "Longitud del mensaje original: 26",
            "Longitud del mensaje procesado: 18",  // 19 en el original
            "Palabra extraída: mundo",
            "¿La palabra es \"mundo\"? true"
        };

        ExerciseStringsI exercise = new ExerciseStringsI();
        String[] outputMessage = exercise.processSecretMessage(caseValue);

        String output;
        String expected;
        for (int i = 0; i < expectedLines.length; i++) {
            expected = expectedLines[i];
            output = outputMessage[i];
            assertEquals(expected, output);
        }
    }

    @Test
    void shouldReplaceUnderscoresWithSpaces() {
        String caseValue = "   Hola_mundo secreto__   ";
        String expected = "   Hola mundo secreto     ";

        ExerciseStringsI exercise = new ExerciseStringsI();
        String output = exercise.replaceUnderscores(caseValue);

        assertEquals(expected, output);
    }

    @Test
    void shouldRemoveExtraSpaces() {
        String caseValue = "   Hola_mundo secreto     ";
        String expected = "Hola_mundo secreto";

        ExerciseStringsI exercise = new ExerciseStringsI();
        String output = exercise.removeExtraSpaces(caseValue);

        assertEquals(expected, output);
    }

    @Test
    void shouldDetectIfTheWordIsMundo() {
        String caseValue1 = "mundo";
        String caseValue2 = "mundors";
        Boolean expected1 = true;
        Boolean expected2 = false;

        ExerciseStringsI exercise = new ExerciseStringsI();
        Boolean output1 = exercise.isMundo(caseValue1);
        assertEquals(expected1, output1);
        Boolean output2 = exercise.isMundo(caseValue2);
        assertEquals(expected2, output2);
    }

    @Test
    void extractedWordIsMundo() {
        String caseValue = "Hola mundo secreto";
        String expected = "mundo";

        ExerciseStringsI exercise = new ExerciseStringsI();
        String output = exercise.extractWord(caseValue);

        assertEquals(expected, output);
    }
}