package cl.duoc.edbray.ejercicios.str1;

import cl.duoc.edbray.ejercicios.utilities.UserInputsOutputs;

import java.util.Locale;

public class ExerciseStringsI {
    private final UserInputsOutputs usrIO = new UserInputsOutputs();

    public void run() {
        String usrInput = usrIO.askString();
        String[] res = processSecretMessage(usrInput);
        usrIO.show(res);
        usrIO.pressEnter();
    }

    public String[] processSecretMessage(String msg) {
        int amountOfProcesses = 6;
        String[] res = {
            "Mensaje original: ",
            "Mensaje procesado: ",
            "Longitud del mensaje original: ",
            "Longitud del mensaje procesado: ",
            "Palabra extraída: ",
            "¿La palabra es \"mundo\"? "
        };

        String processed = fullProcess(msg);

        res[0] += msg;
        res[1] += processed;
        res[2] += msg.length();
        res[3] += processed.length();

        String extractedWord = extractWord(processed);
        res[4] += extractedWord;
        res[5] += isMundo(extractedWord);

        return res;
    }

    public String fullProcess(String msg) {
        String res = replaceUnderscores(msg);
        res = removeExtraSpaces(res);
        return res;
    }

    public String extractWord(String msg) {
        return msg.substring(5, 10);
    }

    public String replaceUnderscores(String msg) {
        return msg.replace("_", " ");
    }

    public String removeExtraSpaces(String msg) {
        return msg.trim();
    }

    public Boolean isMundo(String msg) {
        return msg.equalsIgnoreCase("mundo");
    }
}
