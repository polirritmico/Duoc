package cl.duoc.edbray.ejercicios;

import cl.duoc.edbray.ejercicios.str1.ExerciseStringsI;
import cl.duoc.edbray.ejercicios.str2.ExerciseStringsII;

public class Main {
    public static void main(String[] args) {
        // ExerciseStringsI str1 = new ExerciseStringsI();
        // str1.run();
        ExerciseStringsII str2 = new ExerciseStringsII();
        str2.run();
    }
}
