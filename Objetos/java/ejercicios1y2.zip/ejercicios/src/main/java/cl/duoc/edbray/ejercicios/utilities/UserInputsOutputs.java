package cl.duoc.edbray.ejercicios.utilities;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Scanner;

public class UserInputsOutputs {
    private final Scanner scanner = new Scanner(System.in);

    public void show(String msg) {
        System.out.println(msg);
    }

    public void show(String msg, String value) {
        System.out.println(msg + ": '" + value + "'");
    }

    public void show(String[] msg) {
        for (String line : msg) {
            System.out.println(line);
        }
    }

    public String askString() {
        String msgDefault = "texto";
        return askString(msgDefault);
    }

    public String askString(String msg) {
        msg = "Ingrese " + msg + ": ";
        String msgError = "Debe ingresar un valor.";

        while (true) {
            System.out.print(msg);
            String usrInput = scanner.nextLine();
            if (usrInput.isBlank()) {
                showErrorMessageValue(msgError);
                continue;
            }
            return usrInput;
        }
    }

    public int askInt(String msg) {
        String defaultErrorMsg = "No se ha ingresado un valor numérico, intente nuevamente.";
        return askInt(msg, defaultErrorMsg);
    }

    public int askInt(String msg, String msgError) {
        msg = "Ingrese " + msg + ": ";
        return askIntPreservingMessage(msg, msgError);
    }

    public int askIntPreservingMessage(String msg, String msgError) {
        while (true) {
            System.out.print(msg);
            if (!scanner.hasNextInt()) {
                showErrorMessageValue(msgError);
                scanner.nextLine();
                continue;
            }
            int usrInput = scanner.nextInt();
            scanner.nextLine(); // para consumir el salto de línea del enter

            return usrInput;
        }
    }

    public LocalDate askDate(String msg) {
        String msgError = "Valor de fecha no válido, intente nuevamente.";
        String inputUserRaw;
        int posSepLeft = 4; // 0-idx
        int posSepRight = 7;

        msg = "Ingrese " + msg + " (AAAA-MM-DD): ";
        while (true) {
            System.out.print(msg);
            inputUserRaw = scanner.nextLine();

            // TODO: Esto es un intento básico. Reemplazar con excepciones.
            if (inputUserRaw.length() != 10) {
                showErrorMessageValue(msgError);
                continue;
            }
            if (inputUserRaw.charAt(posSepLeft) != '-' || inputUserRaw.charAt(posSepRight) != '-') {
                showErrorMessageValue(msgError);
                continue;
            }

            LocalDate dateParsed = LocalDate.parse(inputUserRaw);
            return dateParsed;
        }
    }

    public String askRut(String msg) {
        // TODO: Como método específico para validar digito verificador, length, etc.
        return askString("RUT " + msg);
    }

    public void pressEnter() {
        System.out.print("\nPresione Enter para continuar...");
        scanner.nextLine();
    }

    public void showErrorMessageValue() {
        showErrorMessageValue("Valor inválido, intente nuevamente.");
    }

    public void showErrorMessageValue(String msgError) {
        System.out.println(msgError);
    }
}