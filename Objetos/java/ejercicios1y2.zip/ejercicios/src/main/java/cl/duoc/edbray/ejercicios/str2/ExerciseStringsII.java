package cl.duoc.edbray.ejercicios.str2;

import cl.duoc.edbray.ejercicios.utilities.UserInputsOutputs;

public class ExerciseStringsII {
    private final UserInputsOutputs usrIO = new UserInputsOutputs();

    public void run() {
        String res;

        String userInput = usrIO.askString("nombre de usuario");
        usrIO.show("Usuario original", userInput);
        String userInputClean = cleanSpaces(userInput);

        res = userInputClean;
        usrIO.show("Usuario limpio", userInputClean);

        res = Boolean.toString(beginWithUppercase(userInputClean));
        usrIO.show("Comienza con mayúsculas", res);

        res = converToLowercase(userInputClean);
        usrIO.show("Versión en minúscula", res);

        res = Boolean.toString(checkHasNumbers(userInputClean));
        usrIO.show("¿Contiene números?", res);

        res = Boolean.toString(checkEndWithDigit(userInputClean));
        usrIO.show("¿Termina con números?", res);

        res = convertToUppercase(userInputClean);
        usrIO.show("Versión destacada: ", res);

        res = countCharacters(userInputClean);
        usrIO.show("Longitud del usuario", res);
    }

    public String cleanSpaces(String text) {
        String withoutSpaces = text.replace(" ", "");
        return withoutSpaces;
    }

    public boolean beginWithUppercase(String text) {
        char firstLetter = text.charAt(0);
        return Character.isUpperCase(firstLetter);
    }

    public String converToLowercase(String text) {
        return text.toLowerCase();
    }

    public boolean checkHasNumbers(String text) {
        if (text.isBlank()) return false;

        for (char character : text.toCharArray()) {
            if (Character.isDigit(character)) return true;
        }
        return false;
    }

    public boolean checkEndWithDigit(String text) {
        int lastCharPosition = text.length() - 1;
        char lastChar = text.charAt(lastCharPosition);
        return Character.isDigit(lastChar);
    }

    public String convertToUppercase(String text) {
        return text.toUpperCase();
    }

    public String countCharacters(String text) {
        Integer charactersCount = text.length();
        return charactersCount.toString();
    }
}
